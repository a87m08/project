package com.example.un_named.emergencyalert;

import android.content.Context;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.Timer;
import java.util.TimerTask;

public class Assistance extends AppCompatActivity {
    EditText etcode, etpw;
    Button btnRegister;
    Toolbar assistanceToolbar;
    //media
    static MediaPlayer akhlas;

    Timer time;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_assistance);

        etcode = (EditText) findViewById(R.id.etpatientCode);
        etpw = (EditText) findViewById(R.id.etpw);
        btnRegister = (Button) findViewById(R.id.btnRegister);

        //toolbar
        assistanceToolbar = (Toolbar) findViewById(R.id.assistance_toolbar);
        setSupportActionBar(assistanceToolbar);
        getSupportActionBar().setTitle("Registration");

        //Media player after app pause
        akhlas = MediaPlayer.create(getApplicationContext(), R.raw.akhlas);

        //Timer
        time = new Timer();


        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String Code = etcode.getText().toString();
                String PW = etpw.getText().toString();
                if (Code.trim().length() > 0 && PW.trim().length() > 0) {
                    Toast.makeText(Assistance.this, "Successfully Registered", Toast.LENGTH_SHORT).show();
                } else {
                    etcode.setError("Please enter Code");
                    etpw.setError("Please Enter PW ");
                }
            }
        });


    }


    //for alarm when app is close
    @Override
    protected void onPause() {
        super.onPause();

        time.schedule(new TimerTask() {
            @Override
            public void run() {

                //akhlas.start();
                Vibrator v = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
                // Vibrate for 500 milliseconds
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    v.vibrate(VibrationEffect.createOneShot(5000,VibrationEffect.DEFAULT_AMPLITUDE));
                }else{
                    //deprecated in API 26
                    v.vibrate(500);
                }
            }
        }, 60 * 60 * 1000);

    }
}
