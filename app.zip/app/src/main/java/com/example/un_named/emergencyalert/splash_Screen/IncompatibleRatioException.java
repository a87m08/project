package com.example.un_named.emergencyalert.splash_Screen;

/**
 * Created by un_named on 4/25/2018.
 */

public class IncompatibleRatioException extends RuntimeException {

    private static final long serialVersionUID = 234608108593115395L;

    public IncompatibleRatioException() {
        super("Can't perform Ken Burns effect on rects with distinct aspect ratios!");
    }
}
