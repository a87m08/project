package com.example.un_named.emergencyalert;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.drawable.AnimationDrawable;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.CountDownTimer;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.appolica.flubber.Flubber;

import java.util.Timer;
import java.util.TimerTask;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    private Toolbar mainToolbar;
    ImageView imgpatient, imgassistant, imgagent;
    AnimationDrawable animationDrawable;
    RelativeLayout relativeLayout;

    static MediaPlayer akhlas;
    Timer time;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Media player after app pause
        akhlas = MediaPlayer.create(getApplicationContext(), R.raw.akhlas);

        //Timer
        time = new Timer();

        initialization();
        listener();

        //Animation
        animationDrawable = (AnimationDrawable) relativeLayout.getBackground();
        animationDrawable.setEnterFadeDuration(5000);
        animationDrawable.setExitFadeDuration(2000);
// onResume
        animationDrawable.start();
        //ToolBar
        mainToolbar = (Toolbar) findViewById(R.id.main_page_toolbar);
        setSupportActionBar(mainToolbar);
        getSupportActionBar().setTitle("Emergency Call");
        getSupportActionBar().setDisplayShowTitleEnabled(true);


    }


    public void initialization() {
        imgpatient = (ImageView) findViewById(R.id.imgpatient);
        imgassistant = (ImageView) findViewById(R.id.imgassiatant);
        imgagent = (ImageView) findViewById(R.id.imgagent);
        relativeLayout = (RelativeLayout) findViewById(R.id.Rmain_animation);
    }

    public void listener() {
        imgpatient.setOnClickListener(this);
        imgassistant.setOnClickListener(this);
        imgagent.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.imgpatient:
                Flubber.with()
                        .animation(Flubber.AnimationPreset.SLIDE_UP) // Slide up animation
                        .repeatCount(0)                              // Repeat once
                        .duration(1000)                              // Last for 1000 milliseconds(1 second)
                        .createFor(imgpatient)                             // Apply it to the view
                        .start();

                new CountDownTimer(1000, 1000) {
                    public void onFinish() {
                        // When timer is finished
                        // Execute your code here
                        //setContentView(R.layout.activity_main);
                        startActivity(new Intent(getApplicationContext(), Patient.class));

                    }

                    public void onTick(long millisUntilFinished) {
                        // millisUntilFinished    The amount of time until finished.
                    }
                }.start();
                // Start it now
                //     setContentView(R.layout.activity_ptient);

                break;
            case R.id.imgassiatant:
                Flubber.with()
                        .animation(Flubber.AnimationPreset.SLIDE_UP) // Slide up animation
                        .repeatCount(0)                              // Repeat once
                        .duration(1000)                              // Last for 1000 milliseconds(1 second)
                        .createFor(imgassistant)                             // Apply it to the view
                        .start();

                new CountDownTimer(1000, 1000) {
                    public void onFinish() {
                        // When timer is finished
                        // Execute your code here
                        //setContentView(R.layout.activity_main);
                        startActivity(new Intent(getApplicationContext(), Assistance.class));

                    }

                    public void onTick(long millisUntilFinished) {
                        // millisUntilFinished    The amount of time until finished.
                    }
                }.start();
                // Start it now
                break;
            case R.id.imgagent:
                Flubber.with()
                        .animation(Flubber.AnimationPreset.SLIDE_UP) // Slide up animation
                        .repeatCount(0)                              // Repeat once
                        .duration(1000)                              // Last for 1000 milliseconds(1 second)
                        .createFor(imgagent)                             // Apply it to the view
                        .start();

                new CountDownTimer(1000, 1000) {
                    public void onFinish() {
                        // When timer is finished
                        // Execute your code here
                        //setContentView(R.layout.activity_main);

                        startActivity(new Intent(getApplicationContext(), Agent.class));
                    }

                    public void onTick(long millisUntilFinished) {
                        // millisUntilFinished    The amount of time until finished.
                    }
                }.start();
                // Start it now
                break;
        }
    }

    //for alarm when app is close
    @Override
    protected void onPause() {
        super.onPause();

        time.schedule(new TimerTask() {
            @Override
            public void run() {
                //akhlas.start();
                Vibrator v = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
                // Vibrate for 500 milliseconds
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    v.vibrate(VibrationEffect.createOneShot(5000,VibrationEffect.DEFAULT_AMPLITUDE));
                }else{
                    //deprecated in API 26
                    v.vibrate(500);
                }
            }
        }, 60 * 60 * 1000);

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        SharedPreferences sharedPreferences = getSharedPreferences(getString(R.string.PREF_FILE), MODE_PRIVATE);

        String loginInfo = sharedPreferences.getString("loginInfo", null);

        if (loginInfo != null && !loginInfo.equals("")) {

            getMenuInflater().inflate(R.menu.logout, menu);

        }

        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()) {
            case R.id.logout:
                try{
                    SharedPreferences sharedPreferences = getSharedPreferences(getString(R.string.PREF_FILE), MODE_PRIVATE);
                    SharedPreferences.Editor editor = sharedPreferences.edit();

                    editor.clear();
                    editor.commit();

                    startActivity(new Intent(getApplicationContext(), Login.class));
                    finish();
                }
               catch (Exception e){

                   Toast.makeText(this,e+ "", Toast.LENGTH_SHORT).show();
               }
                break;
        }
        return super.onOptionsItemSelected(item);
    }
}
