package com.example.un_named.emergencyalert;

import android.content.Context;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

import com.appolica.flubber.Flubber;

import java.util.Timer;
import java.util.TimerTask;

/**
 * Created by un_named on 4/24/2018.
 */

public class Patient extends AppCompatActivity implements View.OnClickListener {
    private Toolbar patient_Toolbar;
    private ImageView imgfever, imgdizzy, imgheart, imginjuiry;


    static MediaPlayer akhlas;
    Timer time;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ptient);

        initilazaton();
        listener();

        //ToolBar
        patient_Toolbar = (Toolbar) findViewById(R.id.patient_toolbar);
        setSupportActionBar(patient_Toolbar);
        getSupportActionBar().setTitle("Symptoms");
        getSupportActionBar().setDisplayShowTitleEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        //Media player after app pause
        akhlas = MediaPlayer.create(getApplicationContext(), R.raw.akhlas);

        //Timer
        time = new Timer();
    }

    public void initilazaton() {
        imgfever = (ImageView) findViewById(R.id.img_fever);
        imgdizzy = (ImageView) findViewById(R.id.img_dizzy);
        imgheart = (ImageView) findViewById(R.id.img_heart);
        imginjuiry = (ImageView) findViewById(R.id.img_injuiry);


    }

    public void listener() {
        imgfever.setOnClickListener(this);
        imgdizzy.setOnClickListener(this);
        imgheart.setOnClickListener(this);
        imginjuiry.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.img_fever:
                Flubber.with()
                        .animation(Flubber.AnimationPreset.SLIDE_UP) // Slide up animation
                        .repeatCount(0)                              // Repeat once
                        .duration(1000)                              // Last for 1000 milliseconds(1 second)
                        .createFor(imgfever)                             // Apply it to the view
                        .start();

                new CountDownTimer(1000, 1000) {
                    public void onFinish() {
                        //place Intenet here
                        Toast.makeText(Patient.this, "Fever", Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(getApplicationContext(), Send_Message.class));

                    }

                    public void onTick(long millisUntilFinished) {
                        // millisUntilFinished    The amount of time until finished.
                    }
                }.start();
                // Start it now
                break;
            case R.id.img_dizzy:
                Flubber.with()
                        .animation(Flubber.AnimationPreset.SLIDE_UP) // Slide up animation
                        .repeatCount(0)                              // Repeat once
                        .duration(1000)                              // Last for 1000 milliseconds(1 second)
                        .createFor(imgdizzy)                             // Apply it to the view
                        .start();

                new CountDownTimer(1000, 1000) {
                    public void onFinish() {
                        //place Intenet here
                        startActivity(new Intent(getApplicationContext(), Send_Message.class));
                    }

                    public void onTick(long millisUntilFinished) {
                        // millisUntilFinished    The amount of time until finished.
                    }
                }.start();
                break;
            case R.id.img_heart:
                Flubber.with()
                        .animation(Flubber.AnimationPreset.SLIDE_UP) // Slide up animation
                        .repeatCount(0)                              // Repeat once
                        .duration(1000)                              // Last for 1000 milliseconds(1 second)
                        .createFor(imgheart)                             // Apply it to the view
                        .start();

                new CountDownTimer(1000, 1000) {
                    public void onFinish() {
                        //place Intenet here
                        startActivity(new Intent(getApplicationContext(), Send_Message.class));

                    }

                    public void onTick(long millisUntilFinished) {
                        // millisUntilFinished    The amount of time until finished.
                    }
                }.start();
                break;
            case R.id.img_injuiry:
                Flubber.with()
                        .animation(Flubber.AnimationPreset.SLIDE_UP) // Slide up animation
                        .repeatCount(0)                              // Repeat once
                        .duration(1000)                              // Last for 1000 milliseconds(1 second)
                        .createFor(imginjuiry)                             // Apply it to the view
                        .start();

                new CountDownTimer(1000, 1000) {
                    public void onFinish() {
                        //place Intenet here

                        startActivity(new Intent(getApplicationContext(), Send_Message.class));

                    }

                    public void onTick(long millisUntilFinished) {
                        // millisUntilFinished    The amount of time until finished.
                    }
                }.start();
                break;
        }
    }
    //for alarm when app is close
    @Override
    protected void onPause() {
        super.onPause();

        time.schedule(new TimerTask() {
            @Override
            public void run() {
                //akhlas.start();
                Vibrator v = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
                // Vibrate for 500 milliseconds
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    v.vibrate(VibrationEffect.createOneShot(5000,VibrationEffect.DEFAULT_AMPLITUDE));
                }else{
                    //deprecated in API 26
                    v.vibrate(500);
                }
            }
        }, 60 * 60 * 1000);

    }
}
