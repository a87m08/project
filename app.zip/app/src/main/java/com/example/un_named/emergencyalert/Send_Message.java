package com.example.un_named.emergencyalert;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationManager;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.provider.ContactsContract;
import android.provider.Settings;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.telephony.SmsManager;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.Toast;

import java.io.IOException;
import java.util.List;
import java.util.Locale;
import java.util.Timer;
import java.util.TimerTask;

public class Send_Message extends AppCompatActivity implements View.OnClickListener {
    private Toolbar sendmessage_Toolbar;
    private final int REQUEST_CODE = 11;
    EditText editContatc, editMessage;
    ImageView imgContact;
    Button btnSend, btnlocation;
    Geocoder geocoder;
    List<Address> addresses;
    LocationManager locationManager;
    String lattitude, longitude;
    RelativeLayout relativeLayout;
    private static final int REQUEST_LOCATION = 1;
    public String strAdd = "";


    static MediaPlayer akhlas;
    Timer time;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_send__message);
        initialization();
        listener();


        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        if (!locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
            buildAlertMessageNoGps();

        } else if (locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
            try {
                getLocation();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        //ToolBar
        sendmessage_Toolbar = (Toolbar) findViewById(R.id.sendMessage_toolbar);
        setSupportActionBar(sendmessage_Toolbar);
        getSupportActionBar().setTitle("Send Message");
        getSupportActionBar().setDisplayShowTitleEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        Sendmesage();
        //Location
        ActivityCompat.requestPermissions(this, new String[]{android.Manifest.permission.ACCESS_FINE_LOCATION}, REQUEST_LOCATION);


        //Media player after app pause
        akhlas = MediaPlayer.create(getApplicationContext(), R.raw.akhlas);

        //Timer
        time = new Timer();

    }

    public void initialization() {
        editContatc = (EditText) findViewById(R.id.edit_contact);
        imgContact = (ImageView) findViewById(R.id.img_contact);
        editMessage = (EditText) findViewById(R.id.edit_message);
        btnSend = (Button) findViewById(R.id.btn_SendMesage);
        btnlocation = (Button) findViewById(R.id.btn_location);
        relativeLayout = (RelativeLayout) findViewById(R.id.sendmesabe_Rlayout);
    }

    public void listener() {
        imgContact.setOnClickListener(this);
        btnSend.setOnClickListener(this);
        btnlocation.setOnClickListener(this);
        relativeLayout.setOnClickListener(this);
    }

    //Listener
    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.img_contact:
                Intent intent = new Intent(Intent.ACTION_PICK, ContactsContract.Contacts.CONTENT_URI);
                startActivityForResult(intent, REQUEST_CODE);
                break;
            case R.id.btn_SendMesage:

                String number = editContatc.getText().toString();
                String sms = editMessage.getText().toString();
                if (!locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                    buildAlertMessageNoGps();

                } else if (locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                    try {
                        getLocation();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
                try {

                    SmsManager smsManager = SmsManager.getDefault();
                    smsManager.sendTextMessage(number, null, strAdd + "\n" + sms, null, null);
                    Toast.makeText(Send_Message.this, "Sent!", Toast.LENGTH_SHORT).show();
                    locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);

                } catch (Exception e) {
                    Toast.makeText(Send_Message.this, "Failed", Toast.LENGTH_SHORT).show();
                }
                break;
            case R.id.btn_location:
                startActivity(new Intent(getApplicationContext(), SchMessage.class));
                break;
            case R.id.sendmesabe_Rlayout:
                editMessage.requestFocus();
                InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                imm.toggleSoftInput(InputMethodManager.SHOW_FORCED, InputMethodManager.HIDE_IMPLICIT_ONLY);

                break;
        }

    }

    //Pick Contact
    @Override
    public void onActivityResult(int reqCode, int resultCode, Intent data) {
        super.onActivityResult(reqCode, resultCode, data);
        switch (reqCode) {
            case (REQUEST_CODE):
                if (resultCode == Activity.RESULT_OK) {
                    Uri contactData = data.getData();
                    Cursor c = getContentResolver().query(contactData, null, null, null, null);
                    if (c.moveToFirst()) {
                        String contactId = c.getString(c.getColumnIndex(ContactsContract.Contacts._ID));
                        String hasNumber = c.getString(c.getColumnIndex(ContactsContract.Contacts.HAS_PHONE_NUMBER));
                        String num = "";
                        if (Integer.valueOf(hasNumber) == 1) {
                            Cursor numbers = getContentResolver().query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, null, ContactsContract.CommonDataKinds.Phone.CONTACT_ID + " = " + contactId, null, null);
                            while (numbers.moveToNext()) {
                                num = numbers.getString(numbers.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER));
                                // Toast.makeText(Access_Contact.this, "Number="+num, Toast.LENGTH_LONG).show();
                                editContatc.setText(num);
                            }
                        }
                    }
                    break;
                }
        }
    }

    public void Sendmesage() {
        if (ContextCompat.checkSelfPermission(Send_Message.this,
                android.Manifest.permission.SEND_SMS) != getPackageManager().PERMISSION_GRANTED) {
            if (ActivityCompat.shouldShowRequestPermissionRationale(Send_Message.this, android.Manifest.permission.SEND_SMS)) {
                ActivityCompat.requestPermissions(Send_Message.this, new String[]{android.Manifest.permission.SEND_SMS}, 1);
            } else {
                ActivityCompat.requestPermissions(Send_Message.this, new String[]{android.Manifest.permission.SEND_SMS}, 1);
            }
        } else {
//do nothing
        }
    }

    //For SMs sending
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        switch (requestCode) {
            case 1: {
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    if (ContextCompat.checkSelfPermission(Send_Message.this, android.Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED) {
                        //   Toast.makeText(this, "Permision Granted", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(this, "No Permission  granted", Toast.LENGTH_SHORT).show();
                }
            }

            break;
        }

    }

    //Location
    private void getLocation() throws IOException {
        if (ActivityCompat.checkSelfPermission(Send_Message.this, Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission
                (Send_Message.this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {

            ActivityCompat.requestPermissions(Send_Message.this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, REQUEST_LOCATION);

        } else {
            Location location = locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);

            //  Location location1 = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);

            //  Location location2 = locationManager.getLastKnownLocation(LocationManager.PASSIVE_PROVIDER);

            if (location != null) {
                geocoder = new Geocoder(this, Locale.getDefault());
                double latti = location.getLatitude();
                double longi = location.getLongitude();
                lattitude = String.valueOf(latti);
                longitude = String.valueOf(longi);

                Geocoder geocoder = new Geocoder(this, Locale.getDefault());
                try {
                    List<Address> addresses = geocoder.getFromLocation(latti, longi, 1);
                    if (addresses != null) {
                        Address returnedAddress = addresses.get(0);
                        StringBuilder strReturnedAddress = new StringBuilder("");

                        for (int i = 0; i <= returnedAddress.getMaxAddressLineIndex(); i++) {
                            strReturnedAddress.append(returnedAddress.getAddressLine(i)).append("\n");
                        }
                        strAdd = strReturnedAddress.toString();
                        // textView.setText(strAdd);
                      //  Toast.makeText(this, "My Current loction address" + strReturnedAddress.toString(), Toast.LENGTH_SHORT).show();
                        //  Log.w("My Current loction address", strReturnedAddress.toString());
                    } else {
                        Toast.makeText(this, "No Address returned", Toast.LENGTH_SHORT).show();
                        // Log.w("My Current loction address", "No Address returned!");
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    Toast.makeText(this, "Canont get Address!", Toast.LENGTH_SHORT).show();
                    //Log.w("My Current loction address", "Canont get Address!");
                }
            }  else {

                Toast.makeText(this, "Unble to Trace your location", Toast.LENGTH_SHORT).show();

            }
        }
    }


    protected void buildAlertMessageNoGps() {

        final AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage("Please Turn ON your GPS Connection")
                .setCancelable(false)
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    public void onClick(final DialogInterface dialog, final int id) {
                        startActivity(new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS));
                    }
                })
                .setNegativeButton("No", new DialogInterface.OnClickListener() {
                    public void onClick(final DialogInterface dialog, final int id) {
                        dialog.cancel();
                    }
                });
        final AlertDialog alert = builder.create();
        alert.show();
    }
    //for alarm when app is close
    @Override
    protected void onPause() {
        super.onPause();

        time.schedule(new TimerTask() {
            @Override
            public void run() {
              //  akhlas.start();
                Vibrator v = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
                // Vibrate for 500 milliseconds
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    v.vibrate(VibrationEffect.createOneShot(5000,VibrationEffect.DEFAULT_AMPLITUDE));
                }else{
                    //deprecated in API 26
                    v.vibrate(500);
                }
            }
        }, 60 * 60 * 1000);

    }
}
