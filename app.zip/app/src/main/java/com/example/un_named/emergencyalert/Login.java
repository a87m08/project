package com.example.un_named.emergencyalert;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;

public class Login extends AppCompatActivity implements View.OnClickListener {
    Toolbar loginToolbar;
    TextView tvsignup;
    EditText etemail, etpassword;
    Button btnLogin;
    ProgressDialog progressDialog;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        SharedPreferences sharedPreferences = getSharedPreferences(getString(R.string.PREF_FILE), MODE_PRIVATE);

        String loginInfo = sharedPreferences.getString("loginInfo", null);

        if (loginInfo != null && !loginInfo.equals("")) {

            startActivity(new Intent(getApplicationContext(), MainActivity.class));
            finish();

        }

        setContentView(R.layout.activity_login);

        loginToolbar = (Toolbar) findViewById(R.id.login_toolbar);
        setSupportActionBar(loginToolbar);
        getSupportActionBar().setTitle("Loin");

        initilaization();
        listenr();

        progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Loading.....");
    }

    public void initilaization() {
        etemail = (EditText) findViewById(R.id.etemail);
        etpassword = (EditText) findViewById(R.id.etpassword);
        btnLogin = (Button) findViewById(R.id.btnLogin);
        tvsignup = (TextView) findViewById(R.id.tvsignup);
    }

    public void listenr() {
        tvsignup.setOnClickListener(this);
        btnLogin.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btnLogin:
               // startActivity(new Intent(getApplicationContext(), MainActivity.class));
                if (etemail.getText().toString().trim().length() > 0 && etpassword.getText().toString().trim().length() > 0) {

                    new logintask().execute("http://aliimran007.tk/EmergencyAlert/login.php");

                } else {

                    etemail.setError("Invalid email");
                    etpassword.setError("Invalid password");
                }
                break;
            case R.id.tvsignup:
                startActivity(new Intent(getApplicationContext(), SignUp.class));
                break;
        }

    }
    public class logintask extends AsyncTask<String, Void, ArrayList<String>> {

        String email = etemail.getText().toString();
        String pass = etpassword.getText().toString();

        @Override
        protected void onPreExecute() {
            super.onPreExecute();

            progressDialog.show();
        }

        @Override
        protected ArrayList<String> doInBackground(String... strings) {

            HttpURLConnection connection = null;
            URL url = null;

            try {

                url = new URL(strings[0]);
                connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("POST");
                connection.setDoOutput(true);

                OutputStream outputStream = connection.getOutputStream();
                BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(outputStream, "UTF-8"));

                String data = URLEncoder.encode("usermail", "UTF-8") + "=" + URLEncoder.encode(email, "UTF-8") + "&" +

                        URLEncoder.encode("pass", "UTF-8") + "=" + URLEncoder.encode(pass, "UTF-8");

                bufferedWriter.write(data);
                bufferedWriter.flush();
                bufferedWriter.close();
                outputStream.close();

                InputStream inputStream = connection.getInputStream();
                BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream, "UTF-8"));

                StringBuffer buffer = new StringBuffer();

                String line1 = "";
                while ((line1 = reader.readLine()) != null) {

                    buffer.append(line1);
                }

                String finalStaring = buffer.toString();


                ArrayList<String> arrayList = new ArrayList<String>();

                if (finalStaring.trim().charAt(0) == '{') {

                    JSONObject jsonObject = new JSONObject(finalStaring);
                    JSONArray jsonArray = jsonObject.getJSONArray("Server_Response");

                    for (int i = 0; i < jsonArray.length(); i++) {

                        JSONObject finalOjbect = jsonArray.getJSONObject(i);

                        arrayList.add(finalOjbect.getString("id"));
                        arrayList.add(finalOjbect.getString("name"));
                        arrayList.add(finalOjbect.getString("email"));
                        arrayList.add(finalOjbect.getString("age"));
                        arrayList.add(finalOjbect.getString("region"));
                        arrayList.add(finalOjbect.getString("phone"));

                    }

                    return arrayList;

                } else {

                    arrayList.add("Invalid");

                    return arrayList;

                }


            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            }

            return null;
        }

        @Override
        protected void onPostExecute(ArrayList<String> result) {
            super.onPostExecute(result);

            progressDialog.dismiss();
            if (result != null) {

                if (result.size() > 0) {

                    if (result.size() == 1) {

                        etemail.setError("invalid email");
                        etpassword.setError("invalid password");

                    } else {

                        SharedPreferences sharedPreferences = getSharedPreferences(getString(R.string.PREF_FILE), MODE_PRIVATE);
                        SharedPreferences.Editor editor = sharedPreferences.edit();
                        editor.putString("loginInfo", result.get(0));
                        editor.putString("name", result.get(1));
                        editor.putString("email", result.get(2));
                        editor.putString("age", result.get(3));
                        editor.putString("region", result.get(4));
                        editor.putString("phone", result.get(5));

                        editor.commit();

                        startActivity(new Intent(getApplicationContext(), MainActivity.class));
                        finish();

                    }
                } else  {

                    Toast.makeText(Login.this, "Network error!!", Toast.LENGTH_SHORT).show();

                }

            } else {

                Toast.makeText(Login.this, "Network error!!", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
