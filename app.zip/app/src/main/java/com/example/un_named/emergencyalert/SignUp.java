package com.example.un_named.emergencyalert;

import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;

public class SignUp extends AppCompatActivity implements View.OnClickListener {
    Toolbar signupToolbar;
    EditText etname, etemail, etpass, etcpass, etage, etregion, etphone;
    Button btnSignup;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);

        signupToolbar = (Toolbar) findViewById(R.id.signUp_toolbar);
        setSupportActionBar(signupToolbar);
        getSupportActionBar().setTitle("Sign Up");

        initialization();
        listenr();
    }

    public void initialization() {

        etname = (EditText) findViewById(R.id.etname);
        etemail = (EditText) findViewById(R.id.etemail);
        etpass = (EditText) findViewById(R.id.etpassword);
        etcpass = (EditText) findViewById(R.id.etcnfrmpassword);
        etregion = (EditText) findViewById(R.id.etregion);
        etage = (EditText) findViewById(R.id.etage);
        etphone = (EditText) findViewById(R.id.etphone);
        btnSignup = (Button) findViewById(R.id.btnSignup);

    }

    public void listenr() {
        btnSignup.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btnSignup:

                //  startActivity(new Intent(getApplicationContext(), MainActivity.class));
                if (etname.getText().toString().trim().length() > 0 && etpass.getText().toString().trim().length() > 0 &&
                        etemail.getText().toString().trim().length() > 0 && etage.getText().toString().trim().length() > 0 &&
                        etregion.getText().toString().trim().length() > 0 && etphone.getText().toString().trim().length() > 8) {

                    if (etpass.getText().toString().equals(etcpass.getText().toString())) {

                        new loginTask().execute("http://aliimran007.tk/EmergencyAlert/signup.php");

                    } else {

                        etcpass.setError("Password Not Match");
                    }

                } else {

                    if (etname.getText().toString().equals("")) {
                        etname.setError("please enter user name");
                    }
                    if (etpass.getText().toString().equals("")) {
                        etpass.setError("please enter Password");
                    }
                    if (etcpass.getText().toString().equals("")) {
                        etcpass.setError("please Confirm Password");
                    }


                    if (etemail.getText().toString().equals("")) {
                        etemail.setError("please enter email");
                    }

                    if (etage.getText().toString().equals("")) {
                        etage.setError("please enter    Age");
                    }

                    if (etregion.getText().toString().equals("")) {
                        etregion.setError("please enter Region");
                    }

                    if (etphone.getText().toString().trim().length() < 8) {

                        etphone.setError("please enter phone");
                    }

                }
                break;
        }

    }

    public class loginTask extends AsyncTask<String, Void, String> {
        String name = etname.getText().toString();
        String email = etemail.getText().toString();
        String password = etpass.getText().toString();
        String age = etage.getText().toString();
        String region = etregion.getText().toString();
        String phone = etphone.getText().toString();

        @Override
        protected void onPreExecute() {

            super.onPreExecute();
        }

        @Override
        protected String doInBackground(String... params) {
            HttpURLConnection connection = null;
            URL url = null;
            try {
                url = new URL(params[0]);
                connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("POST");
                connection.setDoOutput(true);

                OutputStream outputStream = connection.getOutputStream();
                BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(outputStream, "UTF-8"));

                String data = URLEncoder.encode("name", "UTF-8") + "=" + URLEncoder.encode(name, "UTF-8")
                        + "&" + URLEncoder.encode("password", "UTF-8") + "=" + URLEncoder.encode(email, "UTF-8")
                        + "&" + URLEncoder.encode("email", "UTF-8") + "=" + URLEncoder.encode(password, "UTF-8")
                        + "&" + URLEncoder.encode("age", "UTF-8") + "=" + URLEncoder.encode(age, "UTF-8")
                        + "&" + URLEncoder.encode("region", "UTF-8") + "=" + URLEncoder.encode(region, "UTF-8")
                        + "&" + URLEncoder.encode("phone", "UTF-8") + "=" + URLEncoder.encode(phone, "UTF-8");
                bufferedWriter.write(data);
                bufferedWriter.flush();
                bufferedWriter.close();
                outputStream.close();

                InputStream inputStream = connection.getInputStream();
                BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream, "UTF-8"));
                StringBuffer buffer = new StringBuffer();
                String line = "";
                while ((line = reader.readLine()) != null) {
                    buffer.append(line);
                }
                String finaldata = buffer.toString();
                return finaldata;

            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;

        }


        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);
            // Toast.makeText(SignUp.this, " Successfully Sign Up", Toast.LENGTH_SHORT).show();
            Toast.makeText(getApplicationContext(), result + "", Toast.LENGTH_LONG).show();
            etname.setText("");
            etemail.setText("");
            etpass.setText("");
            etcpass.setText("");
            etregion.setText("");
            etage.setText("");
            etphone.setText("");

        }
    }

}
