package com.example.un_named.emergencyalert;

import android.content.Context;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;

import java.util.Timer;
import java.util.TimerTask;

public class Agent extends AppCompatActivity {
    Toolbar agentToolbar;
    static MediaPlayer akhlas;
    Timer time;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_agent);

        //toolbAR
        agentToolbar = (Toolbar) findViewById(R.id.agent_toolbar);
        setSupportActionBar(agentToolbar);
        getSupportActionBar().setTitle("Agent");

        //Media player after app pause
        akhlas = MediaPlayer.create(getApplicationContext(), R.raw.akhlas);

        //Timer
        time = new Timer();

    }
    //for alarm when app is close
    @Override
    protected void onPause() {
        super.onPause();

        time.schedule(new TimerTask() {
            @Override
            public void run() {
              //  akhlas.start();
                Vibrator v = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
                // Vibrate for 500 milliseconds
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    v.vibrate(VibrationEffect.createOneShot(5000,VibrationEffect.DEFAULT_AMPLITUDE));
                }else{
                    //deprecated in API 26
                    v.vibrate(500);
                }
            }
        }, 60 * 60 * 1000);
            }


    }

